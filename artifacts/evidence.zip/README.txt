DEMO ONLY. Synthetic cache example at now=10: edge expires; live and forever remain.
Notebook cells are unexecuted. Diagram values are synthetic illustrations, not test logs.
